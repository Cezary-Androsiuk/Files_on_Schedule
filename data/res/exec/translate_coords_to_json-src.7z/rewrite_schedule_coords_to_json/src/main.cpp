#include <cstdio>
#include <vector>
#include <string>
#include <filesystem>
#include <fstream>

#include "json.hpp"

using Json = nlohmann::json;

typedef std::vector<std::vector<int>> cordsVector;
typedef std::filesystem::path sfp;
typedef std::vector<sfp> vsfp;
typedef std::string str;
typedef std::vector<str> vstr;



vstr split(str input, str split_by){
    vstr splited;
    size_t pos = 0;
    str buffer;

    while((pos = input.find(split_by)) != str::npos){
        buffer = input.substr(0, pos);
        splited.push_back(buffer);
        input.erase(0, pos + split_by.size());
    }

    splited.push_back(input);

    return splited;
}

void translateFile(sfp file_in, sfp file_out){
    std::ifstream ifile(file_in);
    if(!ifile.good()){
        printf("can not open file: %s \n",file_in.c_str());
        return;
    }

    struct Rect{
        int x;
        int y;
        int width;
        int height;
    };

    // std::vector<Rect> cords;
    // vstr hrefs;
    Json json;

    str buffer;
    int i=0;
    while(std::getline(ifile, buffer)){
        if(!buffer.empty()){
            auto values = split(buffer, " ");
            if(values.size() < 4){
                printf("can not interpret line: %s \n",buffer.c_str());
                ifile.close();
                return;
            }
            Rect rect;
            rect.x = std::stof(values[0]);
            rect.y = std::stof(values[1]);
            rect.width = std::stof(values[2]) - rect.x+1;
            rect.height = std::stof(values[3]) - rect.y+1;

            std::string b_key = std::string("Button_") + std::to_string(i++);
            json[b_key]["rect"]["left"] = rect.x;
            json[b_key]["rect"]["top"] = rect.y;
            json[b_key]["rect"]["width"] = rect.width;
            json[b_key]["rect"]["height"] = rect.height;

            json[b_key]["href"] = str();
        }
    }
    ifile.close();

    std::ofstream ofile(file_out.string());
    ofile << json.dump(4);
    ofile.close();

}

void getDirFiles(str pwd_in, str pwd_out){
    for(const auto& file : std::filesystem::directory_iterator(pwd_in)){
        if(file.is_regular_file()){
            str f_name = file.path().filename().string();
            str new_name = f_name.substr(0, 21); // only date
            new_name += ".buttondata.json";
            sfp file_out = sfp(pwd_out) / new_name;
            // printf("%s -> %s\n", f_name.c_str(), new_name.c_str());
            translateFile(file, file_out);
        }
    }
}

int main(int argc, char ** argv){
    if(argc >= 3){
        getDirFiles(std::string(argv[1]), std::string(argv[2]));
        return 0;
    }
    else{
        printf("run time arguments: \nargument 1: input directory\nargument 2: output directory\n");
        return 1;
    }
}
